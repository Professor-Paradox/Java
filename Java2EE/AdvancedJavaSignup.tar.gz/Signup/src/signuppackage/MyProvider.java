package signuppackage;

public interface MyProvider {
	String username="t_mysql";
	String password="1234";
	String connUrl="jdbc:mysql://localhost:3306/test_database";
}