package signuppackage;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/loginRegister")
public class LoginRegister extends HttpServlet {
	private static final long serialVersionUID = 1L;

    public LoginRegister() {
        super();

    }

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		CustomerDAO cd = new CustomerDAOImpl();
		String userName = request.getParameter("username");
		String password = request.getParameter("password");
		String submitType=request.getParameter("submit");
		Customer c = new Customer();
		c = cd.getCustomer(userName,password);
		
		//		code for login 
		if(submitType.equals("login") && c!=null && c.getUsername()!=null) {
			request.setAttribute("message",c.getUsername());
			request.getRequestDispatcher("welcome.jsp").forward(request,response);
		}
		
		//		code for register
		else if(submitType.equals("register")) {
			c.setPersonalname(request.getParameter("personalname"));
			c.setPassword(password);
			c.setUsername(userName);
			cd.insertCustomer(c);
			request.setAttribute("successMessage","Registration Successful Try Logining Now");
			request.getRequestDispatcher("login.jsp").forward(request,response);
		
	}else {
		request.setAttribute("message","data not found in database, Register again");
		request.getRequestDispatcher("login.jsp").forward(request,response);
	}

}}
